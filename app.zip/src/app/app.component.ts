import { Component } from '@angular/core';
import {FormGroup,FormControl,FormControlName,Validators} from '@angular/forms'
import { AuthenticationService } from './authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  //title = 'lkdproapp';

  /*logout()
  {
    this.authenticationService.logout();
  }

  constructor(public authenticationService:AuthenticationService)
  
  {

  }*/
                            

}