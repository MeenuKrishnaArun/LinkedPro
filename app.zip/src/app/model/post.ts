export interface User
{
   name: string;
   role: string; 
   avatarUrl: string;
   
   
}

export interface PostModel
{
    user: User;
    createdDate: Date;
    content: string;
    imageUrl: string;
}